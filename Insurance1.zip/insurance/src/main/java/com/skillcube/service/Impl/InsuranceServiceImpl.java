package com.skillcube.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skillcube.Entity.Insurance;
import com.skillcube.repo.InsuranceRepo;
import com.skillcube.service.InsuranceService;

@Service
public class InsuranceServiceImpl implements InsuranceService {
	@Autowired
	InsuranceRepo insuranceRepo;
	
	@Override
	public boolean saveInsurance(Insurance i) {
		// TODO Auto-generated method stub
		
		return insuranceRepo.saveInsurance(i);
	}

	@Override
	public Insurance findById(String insuranceid) {
		// TODO Auto-generated method stub
		return insuranceRepo.findById(insuranceid);
	}

	@Override
	public void deleteInsuranceById(String insuranceid) {
		// TODO Auto-generated method stub
		 insuranceRepo.deleteInsuranceById(insuranceid);
	}


}
