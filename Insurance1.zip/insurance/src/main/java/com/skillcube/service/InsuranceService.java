package com.skillcube.service;



import org.springframework.stereotype.Service;

import com.skillcube.Entity.Insurance;


public interface InsuranceService {

	public boolean saveInsurance(Insurance i);
	public Insurance findById(String insuranceid);
	public void deleteInsuranceById(String insuranceid);
	
	}

	

