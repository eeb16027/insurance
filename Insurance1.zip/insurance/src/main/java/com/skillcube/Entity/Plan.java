package com.skillcube.Entity;

public class Plan {
    
	int id;
	String planid;
	int period;
	int amount;
	String planname;
	
	public Plan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Plan(int id, String planid, int period, int amount, String planname) {
		super();
		this.id = id;
		this.planid = planid;
		this.period = period;
		this.amount = amount;
		this.planname = planname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPlanid() {
		return planid;
	}

	public void setPlanid(String planid) {
		this.planid = planid;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getPlanname() {
		return planname;
	}

	public void setPlanname(String planname) {
		this.planname = planname;
	}

	@Override
	public String toString() {
		return "Plan [id=" + id + ", planid=" + planid + ", period=" + period + ", amount=" + amount + ", planname="
				+ planname + "]";
	}
	
	
	
}