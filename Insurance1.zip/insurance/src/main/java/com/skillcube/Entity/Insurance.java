package com.skillcube.Entity;

import java.util.List;

public class Insurance {
	
	int id;
	String insuranceid;
	String type;
	List<Plan> plans;
	
	public Insurance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Insurance(int id, String insuranceid, String type, List<Plan> plans) {
		super();
		this.id = id;
		this.insuranceid = insuranceid;
		this.type = type;
		this.plans = plans;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInsuranceid() {
		return insuranceid;
	}

	public void setInsuranceid(String insuranceid) {
		this.insuranceid = insuranceid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Plan> getPlans() {
		return plans;
	}

	public void setPlans(List<Plan> plans) {
		this.plans = plans;
	}

	@Override
	public String toString() {
		return "Insurance [id=" + id + ", insuranceid=" + insuranceid + ", type=" + type + ", plans=" + plans + "]";
	}
	
	
	
	  
	
	
	  
	
}
