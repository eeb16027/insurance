package com.skillcube;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Insurance1Application {

	public static void main(String[] args) {
		SpringApplication.run(Insurance1Application.class, args);
	}

}
