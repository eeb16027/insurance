package com.skillcube.util;

public class AppConstant {
	
	public static String dbURL = "jdbc:mysql://localhost:3306/project";
	public static String username = "root";
	public static String password = "Ayush@25"; 

}
