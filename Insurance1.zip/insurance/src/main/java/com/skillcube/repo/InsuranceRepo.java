package com.skillcube.repo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.skillcube.Entity.Insurance;
import com.skillcube.Entity.Plan;
import com.skillcube.util.AppConstant;

@Repository
public class InsuranceRepo {
Connection con=null;
	
	public void deleteInsuranceById(String insuranceid)
	{
		String sqlInsuranceList="SELECT * FROM insurance where insuranceid =?";
		String sqlDelInsurance="delete  FROM insurance where insuranceid =?";
		try {
			
			con= DriverManager.getConnection(AppConstant.dbURL, AppConstant.username, AppConstant.password);
			PreparedStatement ps=con.prepareStatement(sqlInsuranceList);
			ps.setString(1, insuranceid);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				deletePlanById(rs.getInt(3));
				
			}
			
			  ps=con.prepareStatement(sqlDelInsurance);
			  ps.setString(1, insuranceid);
			  ps.executeUpdate();

		}
		catch(SQLException ex)
		{
			
			ex.printStackTrace();
		}
		finally {
			
			
		}
		
	}
	
	public void  deletePlanById(int id)
	{
		String delPlan ="delete from plan where id=?";
		try {
			
			con= DriverManager.getConnection(AppConstant.dbURL, AppConstant.username, AppConstant.password);
			PreparedStatement ps=con.prepareStatement(delPlan);
			ps.setInt(1, id);
			ps.executeUpdate();
			
		}
		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
	 
		
		
	}
	
	
	


	public Insurance findById(String insuranceid)
	{
		Insurance i =new Insurance();
		System.out.println("**"+insuranceid+"**");
		String sqlPlanLastInserted="SELECT * FROM insurance where insuranceid =?";
		Plan  plan=null;
		try {
			con= DriverManager.getConnection(AppConstant.dbURL, AppConstant.username, AppConstant.password);
			PreparedStatement ps=con.prepareStatement(sqlPlanLastInserted);
			ps.setString(1, insuranceid);
			ResultSet rs=ps.executeQuery();
			List<Plan> pList= new ArrayList<>();
			while(rs.next())
			{	
				System.out.println("&&&");
				 i.setId(rs.getInt(1));
				 i.setType(rs.getString(2));
				 i.setInsuranceid(rs.getString(4));
				 Plan p=getPlanByPlanId(rs.getInt(3));
				 pList.add(plan);
				 
			}
			i.setPlans(pList);
			
					 
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			return i;
		}
		 
		 
	}
	
	public Plan getPlanByPlanId(int id)
	{
		String sqlPlanLastInserted="SELECT * FROM plan where planid =?";
		Plan  plan=null;
		try {
			con= DriverManager.getConnection(AppConstant.dbURL, AppConstant.username, AppConstant.password);
			PreparedStatement ps=con.prepareStatement(sqlPlanLastInserted);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				plan=new Plan();
				plan.setId(rs.getInt(1));
				plan.setPlanid(rs.getString(2));
				plan.setPeriod(rs.getInt(3));
				plan.setAmount(rs.getInt(4));
				plan.setPlanname(rs.getString(5));
				
				
			}
			
			
			
		 
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			return plan;
		}
		
		
	}
	
	
	
	public boolean saveInsurance(Insurance i)
	{
		boolean b= true;
		try {
		 
		 List<Plan> planList=i.getPlans();
		 
		 for(Plan p:planList)
		 {
			 	int piD=savePlan(p);
			  	//System.out.println(pId);
 				String sqlInsurance="insert into insurance (type,planid,insuranceid) values (?,?,?)";	
 				con= DriverManager.getConnection(AppConstant.dbURL, AppConstant.username, AppConstant.password);
 				PreparedStatement ps=con.prepareStatement(sqlInsurance);
 				ps.setString(1,i.getType());
 				ps.setInt(2, piD);
 				ps.setString(3, i.getInsuranceid());
 				ps.executeUpdate();
		 }
		 
		}catch(SQLException e)
		{
			e.printStackTrace();
			b=false;
			
		}
		catch(Exception e) {
			b=false;
		}
		finally {
			
			return b;
		}
		
	}
	
	
	public int savePlan(Plan p)
	{
		 int pId=0;
		 String sqlPlan="insert into plan (planid,period,amount,planname) values (?,?,?) ";	
		 try {
			con= DriverManager.getConnection(AppConstant.dbURL, AppConstant.username, AppConstant.password);
			PreparedStatement ps=con.prepareStatement(sqlPlan);
			ps.setString(1, p.getPlanid());
			ps.setInt(2, p.getPeriod());
			ps.setInt(3, p.getAmount());
			ps.setString(4, p.getPlanname());
			
			ps.executeUpdate();
			pId=getLastPlanId();
				
		 
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			return pId;
		}
		
	}
	
	public int getLastPlanId()
	{
		String sqlPlanLastInserted="SELECT * FROM plan order by id desc limit 1";
		int pId=0;
		try {
			con= DriverManager.getConnection(AppConstant.dbURL, AppConstant.username, AppConstant.password);
			PreparedStatement ps=con.prepareStatement(sqlPlanLastInserted);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				pId=rs.getInt(1);
				
			}
			
			
			
		 
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			return pId;
		}
		
		
	}
	
	
	

}
