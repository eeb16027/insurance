package com.skillcube.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.skillcube.Entity.Insurance;
import com.skillcube.service.InsuranceService;

@RestController

public class InsuranceController {

	@Autowired
	InsuranceService insuranceService;
	
	@GetMapping("/insurance/{insuranceid}")
	public ResponseEntity<Insurance> getInsuranceById(@RequestParam String id)
	{
		Insurance i= insuranceService.findById(id);
		return ResponseEntity.ok().body(i);
		
		
	}
	
	@PostMapping("/insurance")
	public ResponseEntity<String> saveInsurance(@RequestBody Insurance i)
	{
		Boolean b= insuranceService.saveInsurance(i);
		if(b==true)
		{
			return ResponseEntity.
				status(HttpStatus.CREATED).
				body("Created");
		}
		else
		{
			return ResponseEntity.
				status(HttpStatus.CONFLICT).
				body("Failed");
			
		}
			 
	}
	
	@DeleteMapping("/insurance/{insuranceid}")
	public ResponseEntity<String> deleteInsuranceById(@PathVariable String insuranceid)
	{
		
		insuranceService.deleteInsuranceById(insuranceid);
		return ResponseEntity.
				status(HttpStatus.OK).
				body("Deleted");
			
		
	}



}
